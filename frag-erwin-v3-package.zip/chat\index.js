const https = require('https');

module.exports = async function (context, req) {
    const method = (req.method || '').toUpperCase();
    context.log(`Incoming ${method || 'UNKNOWN'} request`);

    const allowedOrigins = new Set([
        'https://paulgkwr.github.io',
        'https://frag-erwin.info',
        'https://www.frag-erwin.info',
        'http://localhost:5500',
        'http://127.0.0.1:5500'
    ]);
    const requestOrigin = req.headers?.origin;
    const effectiveOrigin = allowedOrigins.has(requestOrigin) ? requestOrigin : 'https://paulgkwr.github.io';

    const corsHeaders = {
        'Access-Control-Allow-Origin': effectiveOrigin,
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Vary': 'Origin',
        'Content-Type': 'application/json'
    };

    if (method === 'OPTIONS') {
        context.res = {
            status: 200,
            headers: corsHeaders,
            body: ''
        };
        return;
    }

    if (method === 'GET') {
        context.res = {
            status: 200,
            headers: corsHeaders,
            body: JSON.stringify({
                status: 'healthy',
                service: 'Frag Erwin Chat API',
                timestamp: new Date().toISOString()
            })
        };
        return;
    }

    if (method !== 'POST') {
        context.res = {
            status: 405,
            headers: corsHeaders,
            body: JSON.stringify({ error: `Method ${method} not allowed` })
        };
        return;
    }

    // Chat endpoint
    try {
        let payload = req.body;
        if (!payload && req.rawBody) {
            try {
                payload = JSON.parse(req.rawBody);
            } catch (parseError) {
                context.log('Failed to parse rawBody:', parseError);
            }
        }

        if (typeof payload === 'string') {
            try {
                payload = JSON.parse(payload);
            } catch (parseError) {
                context.log('Failed to parse payload string:', parseError);
            }
        }

        const userMessage = payload?.message;

        if (!userMessage) {
            context.log('Request payload missing message field:', payload);
            context.res = {
                status: 400,
                headers: corsHeaders,
                body: JSON.stringify({ error: 'Message is required' })
            };
            return;
        }

        const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
        const apiKey = process.env.AZURE_OPENAI_KEY;
        const deployment = process.env.AZURE_OPENAI_DEPLOYMENT;
        const apiVersion = process.env.AZURE_OPENAI_API_VERSION;

        if (!endpoint || !apiKey || !deployment) {
            context.log('Missing environment variables');
            context.res = {
                status: 500,
                headers: corsHeaders,
                body: JSON.stringify({ error: 'Server configuration error' })
            };
            return;
        }

        // Azure OpenAI API call using native https
        const url = `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`;
        
        const postData = JSON.stringify({
            messages: [
                {
                    role: 'system',
                    content: 'Du bist Erwin, ein hilfreicher Assistent der Stadtwerke, spezialisiert auf Fragen zu Abwassergebühren. Antworte kurz, präzise und freundlich auf Deutsch.'
                },
                {
                    role: 'user',
                    content: userMessage
                }
            ],
            max_tokens: 500,
            temperature: 0.7
        });

        const response = await new Promise((resolve, reject) => {
            const urlObj = new URL(url);
            const options = {
                hostname: urlObj.hostname,
                path: urlObj.pathname + urlObj.search,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'api-key': apiKey,
                    'Content-Length': Buffer.byteLength(postData)
                }
            };

            const req = https.request(options, (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => {
                    if (res.statusCode === 200) {
                        resolve(JSON.parse(data));
                    } else {
                        const errorPayload = {
                            statusCode: res.statusCode,
                            body: data
                        };
                        reject(new Error(JSON.stringify(errorPayload)));
                    }
                });
            });

            req.on('error', reject);
            req.write(postData);
            req.end();
        });

        const assistantMessage = response.choices?.[0]?.message?.content || 
            'Entschuldigung, ich konnte keine Antwort generieren.';

        context.res = {
            status: 200,
            headers: corsHeaders,
            body: JSON.stringify({
                message: assistantMessage,
                timestamp: new Date().toISOString()
            })
        };

    } catch (error) {
    context.log('Error:', error);
        context.res = {
            status: 500,
            headers: corsHeaders,
            body: JSON.stringify({
                error: 'Internal server error',
                message: error.message
            })
        };
    }
};
